#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 20

typedef struct {
    int row;
    int col;
    int value;
} Term;

void fast_transpose(Term a[], int num_nonzero, int rows, int cols, Term b[]) {
    // �� ���� 0�� �ƴ� ��� �� ���
    int row_terms[MAX_SIZE] = { 0 };
    for (int i = 0; i < num_nonzero; i++) {
        row_terms[a[i].col]++;
    }

    // �� ���� ���� ��ġ ���
    int starting_pos[MAX_SIZE] = { 0 };
    starting_pos[0] = 1;
    for (int i = 1; i < cols; i++) {
        starting_pos[i] = starting_pos[i - 1] + row_terms[i - 1];
    }

    // ��ġ ��� ����
    for (int i = 0; i < num_nonzero; i++) {
        int j = starting_pos[a[i].col]++;
        b[j].row = a[i].col;
        b[j].col = a[i].row;
        b[j].value = a[i].value;
    }
}

int main() {
    FILE* inputFile = fopen("input.txt", "r");
    FILE* outputFile = fopen("output.txt", "w");

    if (inputFile == NULL || outputFile == NULL) {
        printf("Error opening files.\n");
        return 1;
    }

    int rows, cols;
    fscanf(inputFile, "%d", &rows);
    cols = rows;

    Term* A = (Term*)malloc(MAX_SIZE * MAX_SIZE * sizeof(Term));
    Term* B = (Term*)malloc(MAX_SIZE * MAX_SIZE * sizeof(Term));

    if (A == NULL || B == NULL) {
        printf("Memory allocation failed.\n");
        fclose(inputFile);
        fclose(outputFile);
        return 1;
    }

    int num_nonzero = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            fscanf(inputFile, "%d", &A[num_nonzero].value);
            if (A[num_nonzero].value != 0) {
                A[num_nonzero].row = i;
                A[num_nonzero].col = j;
                num_nonzero++;
            }
        }
    }

    fast_transpose(A, num_nonzero, rows, cols, B);

    fprintf(outputFile, "%d\n", num_nonzero);
    for (int i = 1; i < num_nonzero+1; i++) {
        fprintf(outputFile, "%d %d %d\n", B[i].row, B[i].col, B[i].value);
    }

  

    printf("Fast transpose completed successfully.\n");

    return 0;
}
