#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

#define MAX_NODES 15

// Define a structure for a node in the binary tree
typedef struct TreeNode {
    int data;
    int left_child_index;
    int right_child_index;
} TreeNode;

// Define the array to store nodes
TreeNode treeArray[MAX_NODES];

// Function to initialize the tree
void initTree() {
    for (int i = 0; i < MAX_NODES; i++) {
        treeArray[i].data = -1; // Initialize data to -1 (indicating an empty node)
        treeArray[i].left_child_index = -1;
        treeArray[i].right_child_index = -1;
    }
}

// Function to create a new node
int createNode(int value) {
    for (int i = 0; i < MAX_NODES; i++) {
        if (treeArray[i].data == -1) { // Find an empty slot in the array
            treeArray[i].data = value;
            return i; // Return the index of the created node
        }
    }
    printf("Binary tree is full. Cannot insert more nodes.\n");
    return -1; // Return -1 if the tree is full
}

// Function to set the left child of a node
void setLeftChild(int parent_index, int child_index) {
    if (parent_index >= 0 && parent_index < MAX_NODES && child_index >= 0 && child_index < MAX_NODES) {
        treeArray[parent_index].left_child_index = child_index;
    }
}

// Function to set the right child of a node
void setRightChild(int parent_index, int child_index) {
    if (parent_index >= 0 && parent_index < MAX_NODES && child_index >= 0 && child_index < MAX_NODES) {
        treeArray[parent_index].right_child_index = child_index;
    }
}

// Function to perform inorder traversal recursively
void inorderTraversal(int root_index) {
    if (root_index != -1) {
        inorderTraversal(treeArray[root_index].left_child_index);
        printf("%d ", treeArray[root_index].data);
        inorderTraversal(treeArray[root_index].right_child_index);
    }
}

int main(int argc, char *argv[]) {
    // Initialize the tree
    initTree();

    FILE* input = fopen(argv[1], "r");
    if (!input) {
        perror("Error opening input file");
        return 1;
    }

    int n;
    fscanf(input, "%d", &n); // Read the number of nodes

    // Read the data from the file and construct the binary tree
    int root_index = -1;
    for (int i = 0; i < n; i++) {
        int value;
        fscanf(input, "%d", &value);
        if (i == 0) {
            // Create the root node
            root_index = createNode(value);
        }
        else {
            // Create child nodes and connect them to the parent node
            int current_index = root_index;
            while (1) {
                if (value < treeArray[current_index].data) {
                    if (treeArray[current_index].left_child_index == -1) {
                        int child_index = createNode(value);
                        setLeftChild(current_index, child_index);
                        break;
                    }
                    else {
                        current_index = treeArray[current_index].left_child_index;
                    }
                }
                else {
                    if (treeArray[current_index].right_child_index == -1) {
                        int child_index = createNode(value);
                        setRightChild(current_index, child_index);
                        break;
                    }
                    else {
                        current_index = treeArray[current_index].right_child_index;
                    }
                }
            }
        }
    }
    fclose(input);

    // Perform inorder traversal starting from the root
    printf("Inorder traversal: ");
    inorderTraversal(root_index);
    printf("\n");

    return 0;
}
