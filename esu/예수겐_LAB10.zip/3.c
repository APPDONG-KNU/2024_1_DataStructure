#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

// Define a structure for a node in the binary tree
typedef struct TreeNode {
    int data;
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

// Function to create a new node
TreeNode* createNode(int value) {
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    if (newNode == NULL) {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }
    newNode->data = value;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

// Function to insert a node into the binary tree
TreeNode* insertNode(TreeNode* root, int value) {
    if (root == NULL) {
        return createNode(value);
    }
    if (value < root->data) {
        root->left = insertNode(root->left, value);
    }
    else if (value > root->data) {
        root->right = insertNode(root->right, value);
    }
    return root;
}

// Function to perform inorder traversal recursively
void inorderTraversal(TreeNode* root) {
    if (root != NULL) {
        inorderTraversal(root->left);
        printf("%d ", root->data);
        inorderTraversal(root->right);
    }
}

// Function to free the memory allocated for the tree
void freeTree(TreeNode* root) {
    if (root != NULL) {
        freeTree(root->left);
        freeTree(root->right);
        free(root);
    }
}

int main(int argc, char* argv[]) {
    TreeNode* root = NULL;

    // Read input data and insert into the binary tree
    FILE* input = fopen(argv[1], "r");
    if (input == NULL) {
        perror("Error opening input file");
        return EXIT_FAILURE;
    }

    int n;
    fscanf(input, "%d", &n); // Read the number of nodes

    for (int i = 0; i < n; i++) {
        int value;
        fscanf(input, "%d", &value);
        root = insertNode(root, value);
    }
    fclose(input);

    // Perform inorder traversal starting from the root
    printf("Inorder traversal: ");
    inorderTraversal(root);
    printf("\n");

    // Free the memory allocated for the tree
    freeTree(root);

    return EXIT_SUCCESS;
}
