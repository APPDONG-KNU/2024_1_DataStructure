﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

#define MAX_NODES 15

int tree[MAX_NODES];
int size = 0;

// Function to insert a new node into the binary tree
void insertNode(int data) {
    if (size == MAX_NODES) {
        printf("Tree is full. Cannot insert more nodes.\n");
        return;
    }
    tree[size++] = data;
}

// Function to perform inorder traversal recursively
void inorderTraversal(int index) {
    if (index < size) {
        inorderTraversal(2 * index + 1); // Left child
        printf("%d ", tree[index]);
        inorderTraversal(2 * index + 2); // Right child
    }
}

int main(int argc, char * argv[]) {
    FILE* input = fopen(argv[1], "r");
    if (!input) {
        perror("Error opening input file");
        return 1;
    }

    int n;
    fscanf(input, "%d", &n); // Read the number of nodes

    // Read the data from the file and construct the binary tree
    for (int i = 0; i < n; i++) {
        int value;
        fscanf_s(input, "%d", &value);
        insertNode(value);
    }
    fclose(input);

    // Perform inorder traversal starting from the root
    printf("Inorder traversal: ");
    inorderTraversal(0);
    printf("\n");

    return 0;
}
