#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef enum { lparen, rparen, plus, minus, times, divide, mod, eos, operand } precedence;

void push(precedence item);
precedence pop();
void remove_spaces(char* str);
precedence getToken(char* symbol, int* cnt, char exp[]);
void printToken(precedence token, FILE* f2);
void convertToPostFIx(FILE* f2);
int calculate();
void push2(int item);
int pop2();

precedence* stack;
int top = 0;
int capacity = 2;

int* stack2;
int top2 = -1;
int capacity2 = 2;

char exps[1000];
char exps_postfix[1000];
int isp[] = { 0, 19, 12, 12, 13, 13, 13, 0 };
int icp[] = { 20, 19, 12, 12, 13, 13, 13, 0 };

int main(int argc, char *argv[]) {
    stack = (precedence*)malloc(sizeof(precedence) * capacity);
    stack[0] = eos;

    FILE* f1, * f2;
    f1 = fopen(argv[1], "r");
    f2 = fopen(argv[2], "w");

    if ((f1 == NULL) || (f2 == NULL)) exit(1);

    fgets(exps, 1000, f1);
    remove_spaces(exps);

    convertToPostFIx(f2);

    fclose(f2);
    f2 = fopen(argv[2], "r+");

    stack2 = (int*)malloc(sizeof(int) * capacity2);

    fgets(exps_postfix, 1000, f2);
    exps_postfix[strlen(exps_postfix)] = ' ';

    

    int result = calculate();

    
    fprintf(f2, "\n%d", result);

    fclose(f1);
    fclose(f2);

    free(stack);
    free(stack2);

    return 0;
}

void push(precedence item) {
    if (top >= capacity - 1) {
        capacity *= 2;
        stack = realloc(stack, sizeof(precedence) * capacity);
    }
    stack[++top] = item;
}

void push2(int item) {
    if (top2 >= capacity2 - 1) {
        capacity2 *= 2;
        stack2 = realloc(stack2, sizeof(int) * capacity2);
    }
    stack2[++top2] = item;
}

precedence pop() {
    if (top <= -1) {
        printf("stack is empty\n");
        exit(1);
    }
    return stack[top--];
}

int pop2() {
    if (top2 <= -1) {
        printf("stack2 is empty\n");
        exit(1);
    }
    return stack2[top2--];
}

void remove_spaces(char* str) {
    char* src = str, * dst = str;
    while (*src) {
        if (isspace((unsigned char)*src))
            src++;
        else
            *dst++ = *src++;
    }
}

precedence getToken(char* symbol, int* cnt, char exp[]) {
    *symbol = exp[++(*cnt)];

    switch (*symbol) {
    case '(': return lparen;
    case ')': return rparen;
    case '+': return plus;
    case '-': return minus;
    case '/': return divide;
    case '*': return times;
    case '%': return mod;
    case ' ': return eos;
    default: return operand;
    }
}

void printToken(precedence token, FILE* f2) {
    switch (token) {
    case plus:
        printf("+");
        fprintf(f2, "+");
        break;
    case minus:
        printf("-");
        fprintf(f2, "-");
        break;
    case divide:
        printf("/");
        fprintf(f2, "/");
        break;
    case times:
        printf("*");
        fprintf(f2, "*");
        break;
    case mod:
        printf("%%");
        fprintf(f2, "%%");
        break;
    default:
        break;
    }
}

void convertToPostFIx(FILE* f2) {
    precedence token;
    char symbol;
    int cnt = -1;

    for (token = getToken(&symbol, &cnt, exps); token != eos; token = getToken(&symbol, &cnt, exps)) {
        if (token == operand) {
            printf("%c", symbol);
            fprintf(f2, "%c", symbol);
        }
        else if (token == rparen) {
            while (stack[top] != lparen) {
                printToken(pop(), f2);
            }
            pop();
        }
        else {
            while (isp[stack[top]] >= icp[token]) {
                printToken(pop(), f2);
            }
            push(token);
        }
    }

    while ((token = pop()) != eos)
        printToken(token, f2);

    puts("");
}

int calculate() {
    precedence token;
    char symbol;
    int op1, op2;
    int cnt = -1;
    int i = 0;

    token = getToken(&symbol, &cnt, exps_postfix);

    while (token != eos) {
        if (token == operand) {
            push2(symbol - '0');
        }
        else {
            op2 = pop2();
            op1 = pop2();

            switch (token) {
            case plus:
                push2(op1 + op2);
                break;
            case minus:
                push2(op1 - op2);
                break;
            case times:
                push2(op1 * op2);
                break;
            case divide:
                push2(op1 / op2);
                break;
            case mod:
                push2(op1 % op2);
                break;
            default:
                break;
            }
        }
        token = getToken(&symbol, &cnt, exps_postfix);
    }

    return pop2();
}
