
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define MAX_SIZE 20

// ��� ���� �Լ�
void matrixMultiplication(int n, int A[MAX_SIZE][MAX_SIZE], int B[MAX_SIZE][MAX_SIZE], int result[MAX_SIZE][MAX_SIZE]) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            result[i][j] = 0;
            for (int k = 0; k < n; k++) {
                result[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

int main() {
    int n;
    int A[MAX_SIZE][MAX_SIZE], B[MAX_SIZE][MAX_SIZE], result[MAX_SIZE][MAX_SIZE];

    // input.txt ���� ����
    FILE* inputFile = fopen("input.txt", "r");
    if (inputFile == NULL) {
        printf("Error opening input.txt file.\n");
        return 1;
    }

    // n �� �б�
    fscanf(inputFile, "%d", &n);
    if (n <= 0 || n > MAX_SIZE) {
        printf("Invalid value of n.\n");
        fclose(inputFile);
        return 1;
    }

    // �� ��� ������ �Է� �ޱ�
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fscanf(inputFile, "%d", &A[i][j]);
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fscanf(inputFile, "%d", &B[i][j]);
        }
    }

    // input.txt ���� �ݱ�
    fclose(inputFile);

    // ��� ���� ����
    matrixMultiplication(n, A, B, result);

    // output.txt ���� ����
    FILE* outputFile = fopen("output.txt", "w");
    if (outputFile == NULL) {
        printf("Error opening output.txt file.\n");
        return 1;
    }

    // ��� ���
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fprintf(outputFile, "%d ", result[i][j]);
        }
        fprintf(outputFile, "\n");
    }

    // output.txt ���� �ݱ�
    fclose(outputFile);

    return 0;
}
