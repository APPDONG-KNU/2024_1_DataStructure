#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define MAX_SIZE 10

// COMPARE ��ũ�� ����
#define COMPARE(x, y) ((x) < (y) ? -1 : ((x) == (y) ? 0 : 1))

// �ݺ����� ���� Ž�� �Լ�
int IterativeBinSearch(int nArr[], int nSize, int nTarget) {
    int nBegin = 0;
    int nEnd = nSize - 1;

    while (nBegin <= nEnd) {
        int nMid = (nBegin + nEnd) / 2;

        switch (COMPARE(nArr[nMid], nTarget)) {
        case -1:
            nBegin = nMid + 1;
            break;
        case 0:
            return nMid; // Ÿ���� ã�Ҵ�.
        case 1:
            nEnd = nMid - 1;
            break;
        }
    }

    return -1; // Ž�� ����
}

int main() {
    FILE* inputFile = fopen("input.txt", "r");
    FILE* outputFile = fopen("output.txt", "w");

    if (inputFile == NULL || outputFile == NULL) {
        printf("Error opening files.\n");
        return 1;
    }

    int nArr[MAX_SIZE];
    int nSize;
    fscanf(inputFile, "%d", &nSize);

    // �迭 �б�
    for (int i = 0; i < nSize; ++i) {
        fscanf(inputFile, "%d", &nArr[i]);
    }

    int nTarget;
    fscanf(inputFile, "%d", &nTarget);

    // ���� Ž�� ����
    int nResult = IterativeBinSearch(nArr, nSize, nTarget);

    // ��� ���
    if (nResult == -1) {
        fprintf(outputFile, "-1.\n");
    }
    else {
        for (int i = 0; i < nSize; ++i) {
            fprintf(outputFile, "%d ", nArr[i]);
        }
        fprintf(outputFile, "\n%d��° �迭 ��ҿ� �ֽ��ϴ�.\n", nResult);
    }

    // ���� �ݱ�
    fclose(inputFile);
    fclose(outputFile);

    return 0;
}
