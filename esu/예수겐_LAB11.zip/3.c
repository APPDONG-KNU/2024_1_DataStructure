#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

// Define a structure for a binary tree node
typedef struct Node {
    char data;
    struct Node* left;
    struct Node* right;
} Node;

// Function to create a new node
Node* newNode(char data) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node;
}

// Function to construct the binary tree from input data
Node* constructTree(char* input, int n) {
    Node** nodes = (Node**)malloc(n * sizeof(Node*));
    int i = 0, j = 0;
    while (i < n) {
        if (input[j] != ' ') {
            nodes[i] = newNode(input[j]);
            i++;
        }
        j++;
    }

    for (i = 0; i < n; i++) {
        if (nodes[i] != NULL) {
            if (2 * i + 1 < n) {
                nodes[i]->left = nodes[2 * i + 1];
            }
            if (2 * i + 2 < n) {
                nodes[i]->right = nodes[2 * i + 2];
            }
        }
    }

    Node* root = nodes[0];
    free(nodes);
    return root;
}

// Inorder traversal
void inorder(Node* root) {
    if (root != NULL) {
        inorder(root->left);
        if (root->data != 'N')
            printf("%c", root->data);
        inorder(root->right);
    }
}

// Preorder traversal
void preorder(Node* root) {
    if (root != NULL) {
        if (root->data != 'N')
            printf("%c", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

// Postorder traversal
void postorder(Node* root) {
    if (root != NULL) {
        postorder(root->left);
        postorder(root->right);
        if (root->data != 'N')
            printf("%c", root->data);
    }
}

int main() {
    // Read input from file
    FILE* file = fopen("input.txt", "r");
    if (file == NULL) {
        fprintf(stderr, "Error opening the file.\n");
        return 1;
    }
    int n;
    fscanf(file, "%d", &n);

    char* input = (char*)malloc((n * 2 + 1) * sizeof(char)); // Twice the size to accommodate spaces and null-termination
    fscanf(file, " %[^\n]s", input);

    // Construct the binary tree
    Node* root = constructTree(input, n * 2);

    // Print traversals
    printf("inorder traversal: ");
    inorder(root);
    printf("\n");

    printf("preorder traversal: ");
    preorder(root);
    printf("\n");

    printf("postorder traversal: ");
    postorder(root);
    printf("\n");

    // Free allocated memory (not necessary for this simple program)

    fclose(file);

    return 0;
}
