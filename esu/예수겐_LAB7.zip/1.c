#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct listNode* listpointer;

typedef struct listNode {
    int data;
    listpointer link;
} ListNode;


listpointer createNode(int data);
void insert(listpointer* first, int position, int data);
void deleteP(listpointer* first, int position);
void printList(listpointer first);
int length(listpointer first);

int main(int argc, char *argv[]) {
    listpointer first = NULL;
    int num, n;

    FILE* input = fopen(argv[1], "r");
    if (input == NULL) {
        fprintf(stderr, "Error opening input file.\n");
        return 1;
    }

    while (fscanf(input, "%d", &num) == 1) {
        insert(&first, length(first) + 1, num); // Insert at the end of the list
    }
    fclose(input);

    printList(first);

    printf("+----------------+\n");
    printf("1. insert\n");
    printf("2. delete\n");
    printf("3. length\n");
    printf("4. exit\n");
    printf("+----------------+\n");

    while (1) {
        printf("Menu:");
        scanf("%d", &n);

        switch (n) {
        case 1:
            printf("Enter position and number to insert: ");
            scanf("%d %d", &num, &n);
            insert(&first, num, n);
            printList(first);
            break;
        case 2:
            printf("Enter position to delete: ");
            scanf("%d", &num);
            deleteP(&first, num);
            printList(first);
            break;
        case 3:
            printf("Length of the list: %d\n", length(first));
            break;
        case 4:
            printf("Exit\n");
            break;
        default:
            printf("Invalid option\n");
            break;
        }


    }



    return 0;
}

listpointer createNode(int data) {
    listpointer newNode = (listpointer)malloc(sizeof(ListNode));
    if (newNode == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(1);
    }
    newNode->data = data;
    newNode->link = NULL;
    return newNode;
}

void insert(listpointer* first, int position, int data) {
    listpointer newNode = createNode(data);
    if (position == 1 || *first == NULL) {
        newNode->link = *first;
        *first = newNode;
    }
    else {
        listpointer current = *first;
        int count = 1;
        while (count < position - 1 && current->link != NULL) {
            current = current->link;
            count++;
        }
        newNode->link = current->link;
        current->link = newNode;
    }
}

void deleteP(listpointer* first, int position) {
    if (*first == NULL) {
        printf("List is empty. Nothing to delete.\n");
        return;
    }
    if (position == 1) {
        listpointer temp = *first;
        *first = (*first)->link;
        free(temp);
    }
    else {
        listpointer current = *first;
        int count = 1;
        while (count < position - 1 && current != NULL) {
            current = current->link;
            count++;
        }
        if (current == NULL || current->link == NULL) {
            printf("Invalid position.\n");
            return;
        }
        listpointer temp = current->link;
        current->link = temp->link;
        free(temp);
    }
}

void printList(listpointer first) {
    printf("chain: ");
    for (listpointer temp = first; temp != NULL; temp = temp->link) {
        printf("%d ", temp->data);
    }
    printf("\n");
}

int length(listpointer first) {
    int count = 0;
    for (listpointer temp = first; temp != NULL; temp = temp->link) {
        count++;
    }
    return count;
}