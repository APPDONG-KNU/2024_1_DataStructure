#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct ListNode {
    int data;
    struct ListNode* next;
} ListNode;

ListNode* createNode(int data) {
    ListNode* newNode = (ListNode*)malloc(sizeof(ListNode));
    if (newNode == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(1);
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

void append(ListNode** head, int data) {
    ListNode* newNode = createNode(data);
    if (*head == NULL) {
        *head = newNode;
    }
    else {
        ListNode* temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

ListNode* concatenateChains(ListNode* chain1, ListNode* chain2) {
    if (chain1 == NULL) {
        return chain2;
    }
    ListNode* temp = chain1;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = chain2;
    return chain1;
}

void printChain(ListNode* head) {
    ListNode* temp = head;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main(int argc, char* argv[]) {
    ListNode* chain1 = NULL;
    ListNode* chain2 = NULL;
    int num;

    FILE* input = fopen(argv[1], "r");
    if (input == NULL) {
        fprintf(stderr, "Error opening input file.\n");
        return 1;
    }

    while (fscanf(input, "%d", &num) == 1) {
        append(&chain1, num);
    }
    while (fscanf(input, "%d", &num) == 1) {
        append(&chain2, num);
    }

    fclose(input);

    ListNode* concatenatedChain = concatenateChains(chain1, chain2);

    FILE* output = fopen(argv[2], "w");
    if (output == NULL) {
        fprintf(stderr, "Error opening output file.\n");
        return 1;
    }

    printChain(concatenatedChain);
    ListNode* temp = concatenatedChain;
    while (temp != NULL) {
        fprintf(output, "%d ", temp->data);
        temp = temp->next;
    }
    fprintf(output, "\n");

    fclose(output);

    return 0;
}
