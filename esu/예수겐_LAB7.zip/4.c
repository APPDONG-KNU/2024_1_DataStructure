#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

// Define ListNode structure
typedef struct ListNode {
    int data;
    struct ListNode* next;
} ListNode;

// Define Stack structure
typedef struct Stack {
    ListNode* top;
} Stack;

// Function to create a new ListNode
ListNode* createNode(int data) {
    ListNode* newNode = (ListNode*)malloc(sizeof(ListNode));
    if (newNode == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(1);
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Function to push a ListNode onto the stack
void push(Stack* stack, int data) {
    ListNode* newNode = createNode(data);
    newNode->next = stack->top;
    stack->top = newNode;
}

// Function to pop a ListNode from the stack
int pop(Stack* stack) {
    if (stack->top == NULL) {
        fprintf(stderr, "Stack is empty.\n");
        exit(1);
    }
    int data = stack->top->data;
    ListNode* temp = stack->top;
    stack->top = stack->top->next;
    free(temp);
    return data;
}

// Function to check if the stack is empty
int isEmpty(Stack* stack) {
    return (stack->top == NULL);
}

// Function to free memory allocated for the stack
void freeStack(Stack* stack) {
    ListNode* temp;
    while (stack->top != NULL) {
        temp = stack->top;
        stack->top = stack->top->next;
        free(temp);
    }
}

int main(int argc, char *argv[]) {
    int num;

    // Open input file
    FILE* input = fopen(argv[1], "r");
    if (input == NULL) {
        fprintf(stderr, "Error opening input file.\n");
        return 1;
    }

    // Create stack
    Stack stack;
    stack.top = NULL;

    // Read data from input file and push onto the stack
    while (fscanf(input, "%d", &num) == 1) {
        push(&stack, num);
    }
    fclose(input);

    // Open output file
    FILE* output = fopen(argv[2], "w");
    if (output == NULL) {
        fprintf(stderr, "Error opening output file.\n");
        freeStack(&stack);
        return 1;
    }

    // Pop elements from the stack and print to output file
    while (!isEmpty(&stack)) {
        fprintf(output, "%d ", pop(&stack));
    }
    fprintf(output, "\n");

    fclose(output);

    // Free memory allocated for the stack
    freeStack(&stack);

    return 0;
}
