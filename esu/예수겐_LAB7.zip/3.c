#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct ListNode {
    int data;
    struct ListNode* next;
} ListNode;

ListNode* createNode(int data) {
    ListNode* newNode = (ListNode*)malloc(sizeof(ListNode));
    if (newNode == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(1);
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

void append(ListNode** head, int data) {
    ListNode* newNode = createNode(data);
    if (*head == NULL) {
        *head = newNode;
    }
    else {
        ListNode* temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

ListNode* reverseChain(ListNode* head) {
    ListNode* prev = NULL;
    ListNode* current = head;
    ListNode* next = NULL;
    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    head = prev;
    return head;
}

void printChain(ListNode* head, FILE* output) {
    ListNode* temp = head;
    while (temp != NULL) {
        fprintf(output, "%d ", temp->data);
        temp = temp->next;
    }
}

void freeChain(ListNode* head) {
    ListNode* temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp);
    }
}

int main(int argc, char* argv[]) {
    ListNode* head = NULL;
    int num;

    FILE* input = fopen(argv[1], "r");
    if (input == NULL) {
        fprintf(stderr, "Error opening input file.\n");
        return 1;
    }

    // Read data from input file and create the chain
    while (fscanf(input, "%d", &num) == 1) {
        append(&head, num);
    }
    fclose(input);

    // Reverse the chain
    head = reverseChain(head);

    FILE* output = fopen(argv[2], "w");
    if (output == NULL) {
        fprintf(stderr, "Error opening output file.\n");
        freeChain(head);
        return 1;
    }

    // Print the reversed chain to the output file
    printChain(head, output);
    fprintf(output, "\n");

    fclose(output);

    // Free the memory allocated for the chain
    freeChain(head);

    return 0;
}
