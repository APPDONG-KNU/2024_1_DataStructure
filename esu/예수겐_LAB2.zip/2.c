#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

int main() {
	int n;
	double* argv;
	FILE* inputfile = fopen("input.txt", "r");
	if (inputFile == NULL) {
		printf("Error opening input.txt file.\n");
		return 1;
	}

	fscanf(inputfile, "%d", &n);

	argv = (double*)malloc(n * sizeof(double));

	for (int i = 0; i < n; i++) {
		fscanf(inputfile, "%lf", &argv[i]);
	}
	
	fclose(inputfile);

	
	FILE* outputFile = fopen("output.txt", "w");

	for (int i = 0; i < n; i++) {
		double fractionalPart = argv[i] - (int)argv[i];
		if (fractionalPart != 0) {
			fprintf(outputFile, "%.1lf ", argv[i]);
		}
	}

	fclose(outputFile);

	free(argv);


	return 0;
}