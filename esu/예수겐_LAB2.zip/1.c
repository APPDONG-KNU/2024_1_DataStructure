#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 20

// ��� ���� �Լ�
void matrixAddition(int** A, int** B, int** result, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            result[i][j] = A[i][j] + B[i][j];
        }
    }
}

int main() {
    int n, m; // ��� ���� ��
    int** A, ** B, ** result;

    // input.txt ���� ����
    FILE* inputFile = fopen("input.txt", "r");
    if (inputFile == NULL) {
        printf("Error opening input.txt file.\n");
        return 1;
    }

    // ��� ���� �� �б�
    fscanf(inputFile, "%d %d", &n, &m);
    if (n <= 0 || n > MAX_SIZE || m <= 0 || m > MAX_SIZE) {
        printf("Invalid value of n or m.\n");
        fclose(inputFile);
        return 1;
    }

    // �޸� ���� �Ҵ�
    A = (int**)malloc(n * sizeof(int*));
    B = (int**)malloc(n * sizeof(int*));
    result = (int**)malloc(n * sizeof(int*));
    for (int i = 0; i < n; i++) {
        A[i] = (int*)malloc(m * sizeof(int));
        B[i] = (int*)malloc(m * sizeof(int));
        result[i] = (int*)malloc(m * sizeof(int));
    }

    // ��� ������ �Է� �ޱ�
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            fscanf(inputFile, "%d", &A[i][j]);
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            fscanf(inputFile, "%d", &B[i][j]);
        }
    }

    // ���� �ݱ�
    fclose(inputFile);

    // ��� ���� ����
    matrixAddition(A, B, result, n, m);

    // output.txt ���� ����
    FILE* outputFile = fopen("output.txt", "w");
    if (outputFile == NULL) {
        printf("Error opening output.txt file.\n");
        return 1;
    }

    // ��� ���
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            fprintf(outputFile, "%d ", result[i][j]);
        }
        fprintf(outputFile, "\n");
    }

    // ���� �ݱ�
    fclose(outputFile);

    // �Ҵ�� �޸� ����
    for (int i = 0; i < n; i++) {
        free(A[i]);
        free(B[i]);
        free(result[i]);
    }
    free(A);
    free(B);
    free(result);

    return 0;
}
