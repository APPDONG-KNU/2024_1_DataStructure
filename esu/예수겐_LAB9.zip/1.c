#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define TRUE 1
#define FALSE 0
#define MAX_NUM 24

typedef struct Node {
    int data;
    struct Node* next;
} node;

node** seq;
node* classes[MAX_NUM];
int* out;
int cnt = 0;

void appendNode(int item, int element);
node* createNode(int item);
void appendNode2(int data);
void push(node* new, node** stack);
void categorize();
void sortEquivalenceClass(node* head);

int main(int argc, char *argv[]) {
    FILE* f1, * f2;
    f1 = fopen(argv[1], "r");
    if (f1 == NULL) {
        printf("Error opening input.txt\n");
        exit(1);
    }

    int pairs;
    fscanf(f1, "%d", &pairs);

    seq = (node**)malloc(sizeof(node*) * MAX_NUM);
    out = (int*)malloc(sizeof(int) * MAX_NUM);

    for (int i = 0; i < MAX_NUM; i++) {
        seq[i] = NULL;
        out[i] = FALSE;
    }

    int first, second;

    for (int i = 0; i < pairs; i++) {
        fscanf(f1, "%d = %d", &first, &second);

        out[first] = TRUE;
        out[second] = TRUE;

        appendNode(second, first);
        appendNode(first, second);
    }

    fclose(f1);

    categorize();

    f2 = fopen(argv[2], "w");
    if (f2 == NULL) {
        printf("Error opening output.txt\n");
        exit(1);
    }

    fprintf(f2, "%d\n", cnt);

    for (int i = 0; i < cnt; i++) {
        node* temp = classes[i];
        sortEquivalenceClass(temp); // Sorting equivalence class
        fprintf(f2, "{");
        while (temp != NULL) {
            fprintf(f2, "%d", temp->data);
            if (temp->next != NULL)
                fprintf(f2, ", ");
            temp = temp->next;
        }
        fprintf(f2, "}");
        if (i < cnt - 1)
            fprintf(f2, ", ");
    }

    fclose(f2);

    return 0;
}

node* createNode(int item) {
    node* new = (node*)malloc(sizeof(node));
    if (new == NULL) {
        printf("Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    new->data = item;
    new->next = NULL;

    return new;
}

void appendNode(int item, int element) {
    node* temp = createNode(item);
    temp->next = seq[element];
    seq[element] = temp;
}

void appendNode2(int data) {
    node* new = createNode(data);

    node* temp = classes[cnt];
    if (temp == NULL) {
        classes[cnt] = new;
    }
    else {
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = new;
    }
}

void push(node* new, node** stack) {
    new->next = *stack;
    *stack = new;
}

void categorize() {
    node* temp, * stack;
    int data;

    for (int i = 0; i < MAX_NUM; i++) {
        if (out[i]) {
            classes[cnt] = createNode(i);
            out[i] = FALSE;
            temp = seq[i];
            stack = NULL;

            while (temp != NULL) {
                data = temp->data;

                if (out[data]) {
                    appendNode2(data);
                    out[data] = FALSE;
                    push(temp, &stack);
                }
                temp = temp->next;
            }
            while (stack != NULL) {
                temp = seq[stack->data];
                stack = stack->next;
                while (temp != NULL) {
                    data = temp->data;

                    if (out[data]) {
                        appendNode2(data);
                        out[data] = FALSE;
                        push(temp, &stack);
                    }
                    temp = temp->next;
                }
            }
            cnt += 1;
        }
    }
}

void sortEquivalenceClass(node* head) {
    if (head == NULL || head->next == NULL)
        return;

    node* current = head;
    node* index = NULL;
    int temp;

    while (current != NULL) {
        index = current->next;

        while (index != NULL) {
            if (current->data > index->data) {
                temp = current->data;
                current->data = index->data;
                index->data = temp;
            }
            index = index->next;
        }
        current = current->next;
    }
}
